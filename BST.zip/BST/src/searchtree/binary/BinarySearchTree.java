/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searchtree.binary;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class BinarySearchTree 
{
    Node root;
    
    public BinarySearchTree()
    {
        this.root = null;
    }
    
    public void insert(int value)
    {
        Node newNode = new Node(value);
        if(root == null) 
        {
            root = newNode;
            return;
        }
        
        Node parent = null;
        Node current = root;
        //boolean left = false,right = false;
        
        while(current != null)
        {
            if(value<current.value)
            {
                parent  = current;
                current = current.left;
                if(current == null)
                {
                    parent.left = newNode;
                }
                //left    = true;
                //right   = false;
            }
            else if(value>current.value)
            {
                parent  = current;
                current = current.right;
                if(current == null)
                {
                    parent.right = newNode;
                }
                //right   = true;
                //left    = false;
            }
            else return;
        }
        
        //if(left==true)parent.left = newNode;
        //parent.right = newNode;
    }
    
    public void print(Node src)
    {
        if(src == null )return;
        
        print(src.left);
        
        System.out.println(src.value);
        
        print(src.right);
    }
    
    public boolean find(int value)
    {
        Node current = root;
        
        
        while(current!=null)
        {
            if(current.value == value)return true;
            else if(current.value > value) current = current.left;
            else current = current.right;
            
        }
        return false;
    }
    
    public void delete(int value)
    {
        Node parent = null;
        Node current = root;
        boolean left = false;
        boolean right = false;
        
        //Find the node to be deleted 
        while(current!=null)
        {
            if(current.value == value)break;
            else if(current.value > value) 
            {
                parent  = current;
                current = current.left;
                left    = true;
                right   = false;
            }
            else 
            {
                parent  = current;
                current = current.right;
                left    = false;
                right   = true;
            }
            
        }
        if(left == false && right == false)return;
        
        if(current.left==null && current.right==null)
        {
            if(current == root)root = null;
            
            if(left == true)parent.left = null;
            else if(right == true) parent.right = null;
        }
        else if(current.left!=null && current.right==null)
        {
            if(current == root)
            {
                root = root.left;
            }
            
            Node leftNode = current.left;
            if(left == true)parent.left = leftNode;
            else if(right == true)parent.right = leftNode;
        }
        else if(current.left!=null && current.right!=null)
        {
            Node successorParent = current;
            Node successor = current.right;
            Node successorLeft = current.left;
            
            
            if(successor.left == null)
            {
                if(left == true)
                {
                    parent.left = successor;
                    successor.left = successorLeft;
                }
                else if(right == true)
                {
                    parent.right = successor;
                    successor.left = successorLeft;
                }
                return;
            }
            
            
            while(successor!=null)
            {
                successorParent = successor.instance();
                successor = successor.left.instance();
                //System.out.println(successor.value);
            }
            
            current.value = successor.value;
            successorParent.left = null;
            
        }
        
    }
    
    
    public static void main(String[] args)throws FileNotFoundException, IOException
    {
        BinarySearchTree bst = new BinarySearchTree();
        
        String s = "";
        
        FileReader fr = new FileReader("in.txt");
        BufferedReader br = new BufferedReader(fr);
        
        while( (s = br.readLine())!=null )
        {
            if(s.equalsIgnoreCase("i"))
            {
                int v = Integer.parseInt(br.readLine());
                bst.insert(v);
            }
            else if(s.equalsIgnoreCase("p"))
            {
                bst.print(bst.root);
            }
            else if(s.equalsIgnoreCase("f"))
            {
                int v = Integer.parseInt(br.readLine());
                System.out.println(bst.find(v));
            }
             else if(s.equalsIgnoreCase("d"))
            {
                int v = Integer.parseInt(br.readLine());
                bst.delete(v);
                bst.print(bst.root); 
            }
        }
        
        /*
        Scanner sc = new Scanner(System.in);
        
        while(true)
        {
            char c = sc.next().charAt(0);
            if(c == 'i')
            {
                int v = sc.nextInt();
                bst.insert(v);
            }
            else if(c == 'p')
                bst.print(bst.root); 
        }*/
    }
    
}
