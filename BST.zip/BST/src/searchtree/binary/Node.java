package searchtree.binary;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
class Node 
{
    Node left;
    Node right;
    int value;
    
     
    
    public Node(int value)
    {
        this.value = value;
        this.left = null;
        this.right = null;
    }
    
    public Node instance()
    {
        return this;
    }
    
}
